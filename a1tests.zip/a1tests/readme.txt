The output files were created as follows:

./a1 input < in1 > out1
./a1 input < in2 > out2
 ...

Note that all files are in Unix format.

You may be able to use the runtest bash shell script to automatically run the 
tests.  Simply put your executable (which must be named a1.exe in cygwin or a1
in Unix) in this directory & type: ./runtests

aw
